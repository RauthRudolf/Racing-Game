using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    public CarControl target;
    private Vector3 offsetDir;

    public float minDistance, maxDistance;
    private float activeDistance;

    public Transform startTargetOffset;

    // Start is called before the first frame update
    void Start()
    {
        offsetDir = transform.position - startTargetOffset.position; //how far away from camera

        activeDistance = minDistance;

        offsetDir.Normalize();


    }

    // Update is called once per frame
    void Update()
    {
        activeDistance = minDistance + ((maxDistance - minDistance) * (target.theRB.velocity.magnitude / target.maxSpeed));


        transform.position = target.transform.position + (offsetDir * activeDistance);
    }
}
