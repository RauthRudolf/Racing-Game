using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckpointChecker : MonoBehaviour
{
    public CarControl theCar;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Checkpoint"))
        {
            //Debug.Log("Hit cp" + other.GetComponent<Checkpoint>().cpNumber);
            var checkpoint = other.GetComponent<Checkpoint>();
            if (checkpoint is not null)
            {
                //Debug.Log($"Hit CP {checkpoint.cpNumber}");

                theCar.CheckpointHit(checkpoint.cpNumber);
            }
            else
            {
                //Debug.Log($"Unable to get hit CP");
            }
        }

    }
}
